"""
Meeting Transcriber Module

Realtidstranskribering av möten via Icecast -> Gemini -> Chunk-buffer.
Startas som subprocess av mymem_mcp.py vid watch_meeting("start").
"""
